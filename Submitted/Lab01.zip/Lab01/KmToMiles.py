#!/usr/bin/env python3

#Jordan Banks
#Palomar College CSIT 175
#Lab 1 Excercise 2, convert km to miles

# Variables
miles = float(0.62)

# Input
kilometers_to_convert = float(input("Enter how many Kilometers you need converted:"))

# Process
km = (kilometers_to_convert * miles)

# Output
print(float(kilometers_to_convert), "kilometers converted to miles is" , km)