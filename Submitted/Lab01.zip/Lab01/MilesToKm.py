#!/user/bin/env python3

#Jordan Banks
#Palomar College CSIT 175
#Lab 1 Excercise 3, convert miles to km

# Variables

km = float(.62)

# Input
miles = float(input("Enter the amount of miles: "))

# Process

conversion = float(miles / km)

# Output

print(float(miles),"miles converted to kilometers is", conversion)