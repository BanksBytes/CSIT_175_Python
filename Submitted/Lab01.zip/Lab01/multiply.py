#!/user/bin/env python3

#Jordan Banks
#Palomar College CSIT 175
#Lab 1 Excercise 1, multiple 2 numbers

# declare variables
number1 = 0
number2 = 0
product = 0

# input
number1 = int(input("Enter first number:"))
number2 = int(input("Enter second number:"))

# process

product = number1 * number2

# output

print("The product is " + str(product))