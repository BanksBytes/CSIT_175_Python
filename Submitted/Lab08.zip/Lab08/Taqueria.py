information = {
    "name": "Taco-Dan",
    "phone_number": "800-555-TACO",
    "specials": {
        "Beef Taco": 4.95,
        "Calamari Taco": 5.95,
        "Carne Asada Taco": 5.95,
        "Fish Taco": 4.95,
        "Grilled Fish Taco": 5.95,
        "Shrimp Taco": 5.95,
        "Chicken Taco": 4.95,
        "Pollo Asada Taco": 5.95,
        "Carnitas Taco": 5.95,
        "El Pastor Taco": 5.95,
        "Adobada Taco": 5.95
    }
}