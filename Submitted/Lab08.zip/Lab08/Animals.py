information = {
    "name": "Animal-Man-Dan",
    "phone_number": "800-555-PETS",
    "specials": {
        "Cat": 525.89,
        "Dog": 1210.89,
        "Iguana": 56.89,
        "Snake": 75.95,
        "Fish": 12.95,
        "Bird": 96.95,
        "Tarantula": 75.95,
        "Turtle": 126.50
    }

}