information = {
    "name": "Tire-Man-Dan",
    "phone_number": "800-555-TIRE",
    "specials": {
        "Touring Tires": 544.95,
        "Winter Tires": 465.95,
        "Summer Tires": 425.95,
        "Performance Tires": 654.95,
        "Mud Tires": 335.95,
        "Rugged Terrain Tires": 665.95,
        "Airless Tires": 254.95,
        "Trailer Tires": 795.95
    }
}