information = {
    "name": "Dan-The-Plant-Man",
    "phone_number": "800-555-LEAF",
    "specials": {
        "Aloe Vera (1 gal)": 4.95,
        "Sansevieria (1 gal)": 10.89,
        "Monstera (5 gal)": 25.89,
        "Jade Plant (1 gal)": 12.95,
        "Philodendron ( 1 gal)": 14.95,
        "Orchid (1 gal)": 5.95,
        "Anthurium (1 gal)": 5.95,
        "Calathea (5 gal)": 26.50
    }

}



