information = {
    "name": "Dan-The-Burger-Man",
    "phone_number": "800-555-MEAT",
    "specials": {
        "Cheese Burger": 5.89,
        "Turkey Burger": 6.89,
        "Veggie Burger": 7.89,
        "Chicken Burger": 5.95,
        "Boca Burger": 10.95,
        "Mushroom Burger": 6.95,
        "Bison Burger": 5.95,
        "Bean Burger": 12.50
    }

}